#pragma once

#include "types.h"

extern char str_buffer[];
extern uint32_t buffer_pos;
extern bool ukos;

void keybroad(uint8_t key_code);
void stop_drivers();
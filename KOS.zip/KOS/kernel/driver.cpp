#include "driver.h"
#include "types.h"
#include "display.h"
#include "shell.h"

char str_buffer[256];
uint32_t buffer_pos = 0;
bool ukos = true;
const char keymap[] = {
    0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,
    '*', 0, ' '
};
void keybroad(uint8_t key_code) {
    if (key_code & 0x80) {
        return;
    }
    
    if (key_code < sizeof(keymap)) {
        char c = keymap[key_code];
        
        if (c != 0) {
            if (c == '\b') {
                if (cursor_x > 0) {
                    cursor_x--;
                } else return;
                int index = cursor_y * 80 + cursor_x;
                vga_buffer[index] = (color << 8) | ' ';
                str_buffer[buffer_pos--] = ' ';
                update_cursor();
            } else {
                if (c == '\n') {
                    str_buffer[buffer_pos++]='\0';
                    if (ukos) {
                        shell();
                    }
                    for (int i = 0; i < 256; i++) str_buffer[i]='\0';
                    buffer_pos=0;
                } else str_buffer[buffer_pos++]=c;
                print_char(c);
            }
        }
    }
}

void stop_drivers() {
    
}
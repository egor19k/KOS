#pragma once

#include "types.h"
#include "display.h"

#define SLP_EN (1 << 13)
#define S5_SLEEP_TYPA (5 << 10)

static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}
static inline void outw(uint16_t port, uint16_t val) {
    __asm__ volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("in %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}
static bool str_equals(const char* a, const char* b) {
    while (*a && *b) {
        if (*a != *b) return false;
        a++; b++;
    }
    return *a==*b;
}
static uint8_t str2hex(const char* str) {
    if (str_equals(str, "0")) return 0x0;
    if (str_equals(str, "1")) return 0x1;
    if (str_equals(str, "2")) return 0x2;
    if (str_equals(str, "3")) return 0x3;
    if (str_equals(str, "4")) return 0x4;
    if (str_equals(str, "5")) return 0x5;
    if (str_equals(str, "6")) return 0x6;
    if (str_equals(str, "7")) return 0x7;
    if (str_equals(str, "8")) return 0x8;
    if (str_equals(str, "9")) return 0x9;
    if (str_equals(str, "a") || str_equals(str, "A")) return 0xA;
    if (str_equals(str, "b") || str_equals(str, "B")) return 0xB;
    if (str_equals(str, "c") || str_equals(str, "C")) return 0xC;
    if (str_equals(str, "d") || str_equals(str, "D")) return 0xD;
    if (str_equals(str, "e") || str_equals(str, "E")) return 0xE;
    if (str_equals(str, "f") || str_equals(str, "F")) return 0xF;
    return 0;
}

static char* delim(const char* string, const char del) {
    char* strings = (char*)string;
    if (strings == 0) return 0;
    while (*strings != '\0') {
        if (*strings == del) {
            *strings = '\0';
            return strings + 1;
        }
        strings++;
    }
    return 0;
}
static char* delis(const char* string, const char del) {
    if (string == 0) return 0;
    char* strsta;
    while (*string != '\0') {
        if (*string != del) {
            *strsta = *string;
        } else {
            *strsta = '\0';
            return (char*)strsta;
        }
        string++;
        strsta++;
    }
    return 0;
}
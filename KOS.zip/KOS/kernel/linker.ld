OUTPUT_FORMAT(binary)
ENTRY(kernel_main)

SECTIONS
{
    . = 0x1000;
    .text : {
        *(.text)
    }
    .rodata : {
        *(.rodata)
    }
    .data : {
        *(.data)
    }
    .bss : {
        __bss_start = .;
        *(COMMON)
        *(.bss)
        __bss_end = .;
    }
}
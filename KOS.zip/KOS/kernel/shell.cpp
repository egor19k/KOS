#include "shell.h"
#include "types.h"
#include "display.h"
#include "driver.h"
#include "asmc.h"

uint8_t scolor;
uint8_t cur_color;
uint8_t colKOS;
uint8_t coltext;

SCom ccom[256];

void init_shell() {
    colKOS = 0x01;
    scolor = 0x0F;
    coltext = 0x0F;
    print_string("Shell basic for KOS v1.0\n");
    print_string("Shell in:\n");
}
void shell() {
    cur_color = color;
    color = scolor;
    int index = cursor_y * 80;
    const char* error = executor(str_buffer);
    print_string(error);
    print_string("\nShell in:");
    color = cur_color;
}
void shellup() {
    vga_buffer[77] = (colKOS << 8) | 'K';
    vga_buffer[78] = (colKOS << 8) | 'O';
    vga_buffer[79] = (colKOS << 8) | 'S';
    color = coltext;
    for (int id = 0; id < 256; id++) {
        if (ccom[id].execute != nullptr && ccom[id].used == true) {
            if (ccom[id].task == true) ccom[id].execute((char*)"KOS");
        }
    }
}
void shellap() {
    for (int id = 0; id < 256; id++) {
        if (ccom[id].execute != nullptr && ccom[id].used == true) {
            if (ccom[id].tused == true) ccom[id].execute(str_buffer);
            return;
        }
    }
}

void cadd(uint8_t id, SCom com) {
    ccom[id] = com;
}
void cdel(uint8_t id) {
    ccom[id] = SCom{};
}
int csid(const char* name) {
    for (int id = 0; id < 256; id++) {
        if (str_equals(name, ccom[id].name) && ccom[id].used==true) {
            return id;
        }
    }
    return 0;
}

char* executor(char* cmds) {
    if (cmds == 0) return (char*)"IRS";
    char* p = cmds;
    while (*p != '\0') {
        if (*p == '\r' || *p == '\n') {
            *p = '\0';
            break;
        }
        p++;
    }
    
    char* args[10] = {0};
    int argc = 0;
    
    while (*cmds  == ' ') cmds++;
    if (*cmds == '\0') return (char*)"ISR";
    
    args[argc++] = cmds;
    char* rest = delim(cmds, ' ');
    
    while (rest != 0 && argc < 10) {
        args[argc++] = rest;
        rest = delim(rest, ' ');
    }
    
    print_char('\n');
    if (str_equals(args[0], "help")) {
        color = 0x1F;
        print_string("Available commands:\n");
        color = scolor;
        print_string("  help\n");
        print_string("  clear {color?}\n");
        print_string("  echo [text]\n");
        print_string("  color [background] [foreground]\n");
        print_string("  scolor [background] [foreground]\n");
        for (int id = 0; id < 256; id++) {
            if (ccom[id].name != nullptr && ccom[id].used==true) {
                print_string("  "); print_string(ccom[id].name);
                print_char('\n');
            }
        }
    } else if (str_equals(args[0], "clear") || str_equals(args[0], "cls")) {
        if (args[0] != 0x0) {
            uint8_t ccs = color;
            color = (str2hex(args[1]) << 4 | (0x00) & 0x0F);
            clear_screen();
            color = ccs;
        } else clear_screen();
    } else if (str_equals(args[0], "echo")) {
        print_string(cmds+5);
        print_char('\n');
    } else if (str_equals(args[0], "scolor")) {
        uint8_t col;
        col = (str2hex(args[1]) << 4 | (str2hex(args[2]) & 0x0F));
        scolor = col;
    } else if (str_equals(args[0], "color")) {
        uint8_t col;
        col = (str2hex(args[1]) << 4 | (str2hex(args[2]) & 0x0F));
        coltext = col;
    } else if (str_equals(args[0], "kos")) {
        if (str_equals(args[1], "color")) {
            uint8_t col;
            col = (str2hex(args[2]) << 4 | (str2hex(args[3]) & 0x0F));
            colKOS = col;
        }
    } else {
        for (int id = 0; id < 256; id++) {
            if (str_equals(args[0], ccom[id].name) && ccom[id].used==true) {
                ccom[id].execute(cmds);
                return (char*)"";
            }
        }
        return (char*)"ERROR help to list commands";
    }
    return (char*)"";
}

#include "cmod.h"
#include "display.h"
#include "types.h"
#include "asmc.h"
#include "driver.h"
#include "idt.h"
#include "shell.h"



void Cinit() {
    
}
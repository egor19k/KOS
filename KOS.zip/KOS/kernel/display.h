#pragma once

extern unsigned short* vga_buffer;
extern int cursor_x;
extern int cursor_y;
extern unsigned char color;

void clear_screen();
void print_string(const char* str);
void print_char(char c);
void update_cursor();
#include "types.h"
#include "display.h"
#include "driver.h"
#include "idt.h"
#include "shell.h"
#include "cmod.h"

extern "C" void kernel_main() {
    extern uint32_t __bss_start;
    extern uint32_t __bss_end;
    uint32_t* bss = &__bss_start;
    while (bss < &__bss_end) {
        *bss++ = 0;
    }
    clear_screen();
    color = 0x10;
    print_string("KOS (Kernel Operation System) loaded to ram.\n");
    color = 0x0F;
    init_idt();
    __asm__ volatile ("sti");
    // REMAKE CODE ZONE:
    init_shell();
    Cinit();
    
    while (1) {
        __asm__ volatile ("hlt");
    }
}
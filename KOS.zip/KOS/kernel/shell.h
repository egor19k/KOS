#pragma once

#include "types.h"

typedef struct SCom {
    const char* name;
    bool used;
    void (*execute)(char* arg);
    bool task;
    bool tused;
} SCom;

extern SCom ccom[256];
extern uint8_t scolor;
extern uint8_t colKOS;
void init_shell();
void shell();
void shellup();
void shellap();
char* executor(char* cmds);
void cadd(uint8_t id, SCom com);
void cdel(uint8_t id);
int csid(const char* name);

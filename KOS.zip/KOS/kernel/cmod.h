#pragma once

void Cinit();
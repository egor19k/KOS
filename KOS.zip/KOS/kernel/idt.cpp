#include "idt.h"
#include "types.h"
#include "asmc.h"
#include "pic.h"
#include "driver.h"
#include "shell.h"

extern "C" void isr32();
extern "C" void isr33();
extern "C" void load_idt(uint32_t);

static IDTEntry idt[256];
static IDTPointer idt_ptr;

bool skos = true;

void set_idt_gate(int n, uint32_t handler) {
    idt[n].base_low = handler & 0xFFFF;
    idt[n].base_high =  (handler >> 16) & 0xFFFF;
    idt[n].selector = 0x08;
    idt[n].always0 = 0;
    idt[n].flags = 0x8E;
}

extern "C" void isr_handler(uint32_t int_no) {
    if (int_no == 32) {
        if (skos) {
            shellup();
        } else shellap();
    } else if (int_no == 33) {
        uint8_t scancode = inb(0x60);
        keybroad(scancode);
    }
    if (int_no >= 32 && int_no <= 47) {
        if (int_no >= 40) {
            outb(0xA0, 0x20);
        }
        outb(0x20, 0x20);
    }
}

void init_idt() {
    idt_ptr.limit = sizeof(IDTEntry) * 256 - 1;
    idt_ptr.base = (uint32_t)&idt;
    
    for (int i = 0; i < 256; i++) {
        set_idt_gate(i, 0);
    }
    
    set_idt_gate(32, (uint32_t)isr32);
    set_idt_gate(33, (uint32_t)isr33);
    
    load_idt((uint32_t)&idt_ptr);
    init_pic();
}
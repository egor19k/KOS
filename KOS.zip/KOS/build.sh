#!/bin/sh

clear

if [ "$1" = "mod" ]; then
    rm -r -f /tmp/KOS
    mkdir /tmp/KOS
    cp -r ./* /tmp/KOS
    setsid slayer-editor /tmp/KOS &
    exit
fi
if [ "$1" = "rmod" ]; then
    rm -r -f /tmp/KOS
    exit
fi

rm -r -f /tmp/build
mkdir /tmp/build

find . -type f \( -name '*.cpp' -o -name '*.asm' \) | while read -r f; do
    base=$(basename "$f")
    o="/tmp/build/${base%.*}.o"
    [ "$o" -nt "$f" ] && continue
    case "$f" in
        ./ACP/*) continue ;;
        *.cpp) echo "[CPP] $f"; g++ -m32 -ffreestanding -fno-exceptions -fno-rtti -fno-pic -fno-pie -c "$f" -o "$o" || exit 1 ;;
        *boot.asm) nasm -f bin boot.asm -o /tmp/build/boot.bin || exit 1 ;;
        *.asm) echo "[ASM] $f"; nasm -f elf32 "$f" -o "$o" || exit 1 ;;
    esac
done || exit 1
echo "$(find /tmp/build/ -name '*.o')"
ld -m elf_i386 -T kernel/linker.ld -o /tmp/build/kernel.bin /tmp/build/kernel.o $(find /tmp/build/ -name '*.o' ! -name 'kernel.o' | sort) || exit 1

dd if=/dev/zero of=/tmp/build/os.img bs=1M count=10
dd if=/tmp/build/boot.bin of=/tmp/build/os.img conv=notrunc
dd if=/tmp/build/kernel.bin of=/tmp/build/os.img bs=512 seek=4 conv=notrunc

if [ "$1" = "emu" ]; then
    qemu-system-x86_64 -drive format=raw,file=/tmp/build/os.img -d int -display sdl
fi

exit
